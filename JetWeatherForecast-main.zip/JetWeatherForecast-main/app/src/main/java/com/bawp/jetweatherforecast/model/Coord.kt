package com.bawp.jetweatherforecast.model

data class Coord(
    val lat: Double,
    val lon: Double
)