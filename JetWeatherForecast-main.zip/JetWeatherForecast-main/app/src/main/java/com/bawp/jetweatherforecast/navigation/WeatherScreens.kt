package com.bawp.jetweatherforecast.navigation

enum class WeatherScreens {
    SplashScreen,
    MainScreen,
    AboutScreen,
    FavoriteScreen,
    SearchScreen,
    SettingsScreen
}