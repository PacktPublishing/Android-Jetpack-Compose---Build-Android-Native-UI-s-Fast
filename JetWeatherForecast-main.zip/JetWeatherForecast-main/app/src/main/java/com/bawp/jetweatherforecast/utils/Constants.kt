package com.bawp.jetweatherforecast.utils

object Constants {
    const val   BASE_URL = "https://api.openweathermap.org/"
    const val API_KEY = "ADD_YOUR_OWN_APPID_HERE" // go to: https://openweathermap.org/forecast16
}
