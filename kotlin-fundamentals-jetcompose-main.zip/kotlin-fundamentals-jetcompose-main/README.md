# kotlin-fundamentals-jetcompose
Kotlin fundamentals for compose
In this project, you'll find a 'MyKotlin' module which contains all of the code we wrote while learning Kotlin basics. 
Use this as a reference in your journey to learning Kotlin!

Good luck!
