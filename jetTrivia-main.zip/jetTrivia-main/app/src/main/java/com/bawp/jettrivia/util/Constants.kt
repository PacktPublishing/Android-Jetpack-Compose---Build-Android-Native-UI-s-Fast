package com.bawp.jettrivia.util

object Constants {
    //https://raw.githubusercontent.com/itmmckernan/triviaJSON/master/world.json
    const val BASE_URL = "https://raw.githubusercontent.com/itmmckernan/triviaJSON/master/"
}