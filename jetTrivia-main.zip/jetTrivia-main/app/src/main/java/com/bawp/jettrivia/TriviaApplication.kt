package com.bawp.jettrivia

import android.app.Application
import dagger.hilt.android.HiltAndroidApp

@HiltAndroidApp
class TriviaApplication: Application() {}