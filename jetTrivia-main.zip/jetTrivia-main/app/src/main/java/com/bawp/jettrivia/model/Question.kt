package com.bawp.jettrivia.model

class Question : ArrayList<QuestionItem>()